package com.example.adventcal2018;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

import com.tailf.conf.*;
import com.example.adventcal2018.namespaces.*;
import com.tailf.dp.*;
import com.tailf.maapi.*;
import com.tailf.dp.DpCallbackException;
import com.tailf.dp.DpTrans;
import com.tailf.dp.annotations.DataCallback;
import com.tailf.dp.annotations.TransCallback;
import com.tailf.dp.proto.DataCBType;
import com.tailf.dp.proto.TransCBType;
import java.util.ArrayList;
import java.util.Iterator;
import java.net.Socket;
import org.apache.log4j.Logger;
import com.tailf.ncs.ApplicationComponent;
import com.tailf.ncs.ResourceManager;
import com.tailf.cdb.Cdb;
import com.tailf.cdb.CdbDBType;
import com.tailf.cdb.CdbDiffIterate;
import com.tailf.cdb.CdbException;
import com.tailf.cdb.CdbSession;
import com.tailf.cdb.CdbSubscription;
import com.tailf.cdb.CdbSubscriptionSyncType;
import com.tailf.ncs.annotations.Resource;
import com.tailf.ncs.annotations.ResourceType;
import com.tailf.ncs.annotations.Scope;


public class adventcal2018Dp implements ApplicationComponent  {
    private static final Logger log = Logger.getLogger(adventcal2018Dp.class);

    @Resource(type=ResourceType.CDB, scope=Scope.INSTANCE, qualifier="sub-sock")
    private Cdb cdbSub;
    @Resource(type=ResourceType.CDB,scope=Scope.INSTANCE, qualifier="data-sock")
    private Cdb cdbData;

    private boolean requestStop;
    private int point;
    private CdbSubscription cdbSubscription;
    public void init() {
        log.info(" init cdb subscriber ");

        try {
            cdbSubscription = cdbSub.newSubscription();
            String path="/advent-cal2018:samba";
            point = cdbSubscription.subscribe(1, adventCal2018.hash, path);
            cdbSubscription.subscribeDone();
            requestStop = false;
        } catch (Exception e) {
            log.error("Fail in init",e);
        }
    }

    public void finish(){
        requestStop = true;
        try {
            ResourceManager.unregisterResources(this);
        } catch (Exception e) {
            log.error("Fail in finish",e);
        }
    }
    public void run(){
        try {
            while (!requestStop) {
                try {
                    int[] point = cdbSubscription.read();
                    CdbSession cdbSession =
                        cdbData.startSession(CdbDBType.CDB_RUNNING);
                    EnumSet<DiffIterateFlags> diffFlags =
                        EnumSet.of(DiffIterateFlags.ITER_WANT_PREV);
                    cdbSubscription.diffIterate(point[0], new DiffIterateImpl(),
                                                diffFlags, cdbSession);
                    cdbSession.endSession();
                } finally {
                    cdbSubscription.sync(CdbSubscriptionSyncType.DONE_PRIORITY);
                }
            }
        } catch (Exception e) {
            log.error("Fail in run", e);
        }
        requestStop = false;
    }

    private class DiffIterateImpl implements CdbDiffIterate {
        private Logger log = Logger.getLogger(DiffIterateImpl.class);
        public DiffIterateResultFlag  iterate(ConfObject[] kp,
                                              DiffIterateOperFlag op,
                                              ConfObject oldValue,
                                              ConfObject newValue,
                                              Object initstate) {

            // keypath passed
            // /samba/share{key}
            //   [2]   [1]  [0]
            CdbSession cdbSession = (CdbSession)initstate;

            switch(op){
                case MOP_CREATED: {
                    ConfTag tag = (ConfTag)kp[1];
                    if(tag.getTagHash() == adventCal2018._share){
                        String shareName = ((ConfBuf)((ConfKey)kp[0]).elementAt(0)).toString();
                        String pathName;
                        try {
                            cdbSession.cd("/samba/share{"+shareName+"}");
                            pathName = cdbSession.getElem("path").toString();
                            log.debug("pathname = " + pathName);

                            // adding entry to smb.conf
                            // reload smb.conf
                            log.info(String.format("New share [%s](%s) has been created.", shareName, pathName));
                        }catch(Exception e){
                            log.error("error to read path");
                        }
                    }
                    return DiffIterateResultFlag.ITER_CONTINUE;
                }
                case MOP_DELETED: {
                    ConfTag tag = (ConfTag)kp[1];
                    if(tag.getTagHash() == adventCal2018._share){
                        String shareName = ((ConfBuf)((ConfKey)kp[0]).elementAt(0)).toString();

                        // delete entry from smb.conf
                        // reload smb.conf
                        log.info(String.format("share [%s] has been deleted.", shareName));
                    }
                    return DiffIterateResultFlag.ITER_CONTINUE;
                }
                case MOP_MODIFIED: {
                    ConfTag tag = (ConfTag)kp[1];
                    if(tag.getTagHash() == adventCal2018._share){
                        String shareName = ((ConfBuf)((ConfKey)kp[0]).elementAt(0)).toString();
                        String pathName;
                        try {
                            cdbSession.cd("/samba/share{"+shareName+"}");
                            pathName = cdbSession.getElem("path").toString();
                            log.debug("pathname = " + pathName);

                            // modify smb.conf for shareName
                            // reload smb.conf
                            log.info(String.format("share [%s] has been updated. New path = (%s)", shareName, pathName));
                        }catch(Exception e){
                            log.error("error to read path");
                        }
                        
                    }
                    return DiffIterateResultFlag.ITER_CONTINUE;
                }
            }
            return DiffIterateResultFlag.ITER_RECURSE;
        }
    }
}
